package DAOs;

import Entidades.Apartamento;
import java.util.ArrayList;
import java.util.List;

public class DAOApartamento extends DAOGenerico<Apartamento> {

    private List<Apartamento> lista = new ArrayList<>();

    public DAOApartamento() {
        super(Apartamento.class);
    }

    public int autoIdApartamento() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.cpf) FROM Apartamento e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Apartamento> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Apartamento e WHERE e.cpf) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Apartamento> listById(int id) {
        return em.createQuery("SELECT e FROM Apartamento + e WHERE e.cpf= :id").setParameter("id", id).getResultList();
    }

    public List<Apartamento> listInOrderNome() {
        return em.createQuery("SELECT e FROM Apartamento e ORDER BY e.hospede").getResultList();
    }

    public List<Apartamento> listInOrderId() {
        return em.createQuery("SELECT e FROM Apartamento e ORDER BY e.napartamento").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Apartamento> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getNapartamento()+ "-" + lf.get(i).getHospede());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOApartamento daoApartamento = new DAOApartamento();
        List<Apartamento> listaApartamento = daoApartamento.list();
        for (Apartamento trabalhador : listaApartamento) {
            System.out.println(trabalhador.getNapartamento()+ "-" + trabalhador.getHospede());
        }
    }
}
