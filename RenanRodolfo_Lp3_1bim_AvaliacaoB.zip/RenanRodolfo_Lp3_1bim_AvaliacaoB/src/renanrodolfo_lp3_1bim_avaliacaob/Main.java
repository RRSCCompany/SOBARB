package renanrodolfo_lp3_1bim_avaliacaob;
 
import GUIs.GUI;

public class Main { 
   public static void main(String[] args) {
     GUI gui = new GUI();
   }
}
