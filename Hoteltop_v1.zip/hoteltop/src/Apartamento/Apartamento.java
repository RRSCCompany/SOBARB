package Apartamento;
 
import java.util.Date; 
public class Apartamento { 

private int Numero;
private Double Preco;

 public Apartamento() {
} 

public Apartamento(int Numero,Double Preco) { 

this.Numero = Numero;
this.Preco = Preco;

}

public int getNumero() { 
return Numero; 
} 

public void setNumero(int Numero) { 
this.Numero = Numero; 
} 

public Double getPreco() { 
return Preco; 
} 

public void setPreco(Double Preco) { 
this.Preco = Preco; 
} 


@Override
public String toString() { 
    return Numero + ";" + Preco;
}

}
