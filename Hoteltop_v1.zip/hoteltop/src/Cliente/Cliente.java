package Cliente;
 
import java.util.Date; 
public class Cliente { 

private int ID;
private String Nome;
private String Cpf;
private String Fone;

 public Cliente() {
} 

public Cliente(int ID,String Nome,String Cpf,String Fone) { 

this.ID = ID;
this.Nome = Nome;
this.Cpf = Cpf;
this.Fone = Fone;

}

public int getID() { 
return ID; 
} 

public void setID(int ID) { 
this.ID = ID; 
} 

public String getNome() { 
return Nome; 
} 

public void setNome(String Nome) { 
this.Nome = Nome; 
} 

public String getCpf() { 
return Cpf; 
} 

public void setCpf(String Cpf) { 
this.Cpf = Cpf; 
} 

public String getFone() { 
return Fone; 
} 

public void setFone(String Fone) { 
this.Fone = Fone; 
} 


@Override
public String toString() { 
    return ID + ";" + Nome + ";" + Cpf + ";" + Fone;
}

}
