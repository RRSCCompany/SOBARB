package Reserva2;
 
import java.util.Date; 
public class Reserva2 { 

private int IDCliente;
private int NumeroQuarto;
private Date DiaEntrada;
private Date DiaSaida;

 public Reserva2() {
} 

public Reserva2(int IDCliente,int NumeroQuarto,Date DiaEntrada,Date DiaSaida) { 

this.IDCliente = IDCliente;
this.NumeroQuarto = NumeroQuarto;
this.DiaEntrada = DiaEntrada;
this.DiaSaida = DiaSaida;

}

public int getIDCliente() { 
return IDCliente; 
} 

public void setIDCliente(int IDCliente) { 
this.IDCliente = IDCliente; 
} 

public int getNumeroQuarto() { 
return NumeroQuarto; 
} 

public void setNumeroQuarto(int NumeroQuarto) { 
this.NumeroQuarto = NumeroQuarto; 
} 

public Date getDiaEntrada() { 
return DiaEntrada; 
} 

public void setDiaEntrada(Date DiaEntrada) { 
this.DiaEntrada = DiaEntrada; 
} 

public Date getDiaSaida() { 
return DiaSaida; 
} 

public void setDiaSaida(Date DiaSaida) { 
this.DiaSaida = DiaSaida; 
} 


@Override
public String toString() { 
    return IDCliente + ";" + NumeroQuarto + ";" + DiaEntrada + ";" + DiaSaida;
}

}
