
////////////CONTROLE////////////

package Reserva2; 
import java.util.ArrayList;
import java.util.List;

public class Controle {

private List<Reserva2> lista = new ArrayList<>();

public Controle() { 

} 


public void limparLista(){
   lista.clear(); 
}

public void adicionar(Reserva2 entidade) {
   lista.add(entidade);
}

public List<Reserva2> listar() {
   return lista;
}


public Reserva2 buscar(String IDCliente) {
   for (int i = 0; i < lista.size(); i++) {
      if (String.valueOf(lista.get(i).getIDCliente()).equals(IDCliente)) {
         return lista.get(i);
      }
   }
   return null;
}

public void alterar(Reserva2 entidade,Reserva2 entidadeAntigo) {
   lista.set(lista.indexOf(entidadeAntigo), entidade);
}

public void excluir(Reserva2 entidade) {
   lista.remove(entidade);
}

}
