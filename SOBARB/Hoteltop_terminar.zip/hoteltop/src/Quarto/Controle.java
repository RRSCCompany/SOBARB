
////////////CONTROLE////////////

package Quarto; 
import java.util.ArrayList;
import java.util.List;

public class Controle {

private List<Quarto> lista = new ArrayList<>();

public Controle() { 

} 


public void limparLista(){
   lista.clear(); 
}

public void adicionar(Quarto entidade) {
   lista.add(entidade);
}

public List<Quarto> listar() {
   return lista;
}


public Quarto buscar(String Numero) {
   for (int i = 0; i < lista.size(); i++) {
      if (String.valueOf(lista.get(i).getNumero()).equals(Numero)) {
         return lista.get(i);
      }
   }
   return null;
}

public void alterar(Quarto entidade,Quarto entidadeAntigo) {
   lista.set(lista.indexOf(entidadeAntigo), entidade);
}

public void excluir(Quarto entidade) {
   lista.remove(entidade);
}

}
