
////////////CONTROLE////////////

package Reserva1; 
import java.util.ArrayList;
import java.util.List;

public class Controle {

private List<Reserva1> lista = new ArrayList<>();

public Controle() { 

} 


public void limparLista(){
   lista.clear(); 
}

public void adicionar(Reserva1 entidade) {
   lista.add(entidade);
}

public List<Reserva1> listar() {
   return lista;
}


public Reserva1 buscar(String IDCliente) {
   for (int i = 0; i < lista.size(); i++) {
      if (String.valueOf(lista.get(i).getIDCliente()).equals(IDCliente)) {
         return lista.get(i);
      }
   }
   return null;
}

public void alterar(Reserva1 entidade,Reserva1 entidadeAntigo) {
   lista.set(lista.indexOf(entidadeAntigo), entidade);
}

public void excluir(Reserva1 entidade) {
   lista.remove(entidade);
}

}
