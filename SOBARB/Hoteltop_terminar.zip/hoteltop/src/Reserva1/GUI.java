
////////////GUI////////////

package Reserva1;import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.table.DefaultTableModel;
import tools.ManipulaArquivo;

import tools.DateTextField;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.logging.Level;import java.util.logging.Logger;public class GUI extends JFrame {

private Container cp;



private JLabel lbIDCliente = new JLabel("IDCliente");
private JLabel lbNumeroApartamento = new JLabel("NumeroApartamento");

private JLabel lbdateE = new JLabel("DiaEntrada");
DateTextField dtDiaEntrada = new DateTextField();
private JLabel lbdateS = new JLabel("DiaSaida");
DateTextField dtDiaSaida = new DateTextField();


private JTextField tfIDCliente = new JTextField(50);
private JTextField tfNumeroApartamento = new JTextField(50);

private JButton btAdicionar = new JButton("Adicionar");
private JButton btListar = new JButton("Listar");
private JButton btBuscar = new JButton("Buscar");
private JButton btAlterar = new JButton("Alterar");
private JButton btExcluir = new JButton("Excluir");
private JButton btSalvar = new JButton("Salvar");
private JButton btCancelar = new JButton("Cancelar");
private JButton btCarregarDados = new JButton("Carregar");
private JButton btGravar = new JButton("Gravar");
private JToolBar toolBar = new JToolBar();
private JPanel painelNorte = new JPanel();
private JPanel painelCentro = new JPanel();
private JPanel painelSul = new JPanel();
private JTextArea texto = new JTextArea();
private JScrollPane scrollTexto = new JScrollPane();
private JScrollPane scrollTabela = new JScrollPane();

private String acao = "";
private String chavePrimaria = "";

private Controle controle = new Controle();
private Reserva1 entidade = new Reserva1();


String[] colunas = new String[]{ "IDCliente", "NumeroApartamento", "DiaEntrada", "DiaSaida"};
String[][] dados = new String[0][4];
DefaultTableModel model = new DefaultTableModel(dados, colunas);
JTable tabela = new JTable(model);

private JPanel painel1 = new JPanel(new GridLayout(1, 1));
private JPanel painel2 = new JPanel(new GridLayout(1, 1));
private CardLayout cardLayout;

public GUI() {

String caminhoENomeDoArquivo = "DadosTrabalhador.csv";

setDefaultCloseOperation(DISPOSE_ON_CLOSE);

setSize(600, 400);
setTitle("CRUD Canguru - V6a");
setLocationRelativeTo(null);//centro do monitor

cp = getContentPane()

;cp.setLayout(new BorderLayout());
cp.add(painelNorte, BorderLayout.NORTH);
cp.add(painelCentro, BorderLayout.CENTER);
cp.add(painelSul, BorderLayout.SOUTH);

cardLayout = new CardLayout();
painelSul.setLayout(cardLayout);

painel1.add(scrollTexto);
painel2.add(scrollTabela);

texto.setText("\n\n\n\n\n\n");//5 linhas de tamanho
scrollTexto.setViewportView(texto);

painelSul.add(painel1, "Avisos");
painelSul.add(painel2, "Listagem");
tabela.setEnabled(false);

painelNorte.setLayout(new GridLayout(1, 1));
painelNorte.add(toolBar);

painelCentro.setLayout(new GridLayout(3, 2));


painelCentro.add(lbNumeroApartamento);
painelCentro.add(tfNumeroApartamento);
painelCentro.add(lbdateE);
painelCentro.add(dtDiaEntrada);
painelCentro.add(lbdateS);
painelCentro.add(dtDiaSaida);

toolBar.add(lbIDCliente);
toolBar.add(tfIDCliente);
toolBar.add(btAdicionar);
toolBar.add(btBuscar);
toolBar.add(btListar);
toolBar.add(btAlterar);
toolBar.add(btExcluir);
toolBar.add(btSalvar);
toolBar.add(btCancelar);

btAdicionar.setVisible(false);
btAlterar.setVisible(false);
btExcluir.setVisible(false);
btSalvar.setVisible(false);
btCancelar.setVisible(false);


tfNumeroApartamento.setEditable(false);
dtDiaEntrada.setEnabled(false);
dtDiaSaida.setEnabled(false);
texto.setEditable(false);

btCarregarDados.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      ManipulaArquivo manipulaArquivo = new ManipulaArquivo(); //classe para facilitar o trabalho com arquivos
      if (manipulaArquivo.existeOArquivo(caminhoENomeDoArquivo)) { //só dá para carregar dados se o arquivo existir
         String aux[];
         Reserva1 t;
         List<String> listaStringCsv = manipulaArquivo.abrirArquivo(caminhoENomeDoArquivo);//traz os dados em formato string
         for (String linha : listaStringCsv) {//para cada linha da lista
            aux = linha.split(";");//divida os campos nos ;
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            t = new Reserva1(Integer.valueOf(aux[0]), Integer.valueOf(aux[1]), Date.valueOf(aux[2]), Date.valueOf(aux[3]));//crie um objeto Entidade e preencha com dados.

            controle.adicionar(t); //adicione na lista
         }
         cardLayout.show(painelSul, "Listagem");
      }
   }
});

btGravar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      List<Reserva1> listaEntidade = controle.listar();//obtem a lista toda
      List<String> listaEntidadeEmFormatoStringCSV = new ArrayList<>();
      for (Reserva1 t : listaEntidade) { //percorre toda a lista de trabalhadores
         listaEntidadeEmFormatoStringCSV.add(t.toString());//para cada entidade t, transforme em string.
      }
      new ManipulaArquivo().salvarArquivo(caminhoENomeDoArquivo, listaEntidadeEmFormatoStringCSV);
      System.out.println("gravou");
   }
});

btBuscar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      btAdicionar.setVisible(false);

      cardLayout.show(painelSul, "Avisos");
      scrollTexto.setViewportView(texto);
      if (tfIDCliente.getText().trim().isEmpty()) {
         JOptionPane.showMessageDialog(cp, "IDCliente nâo pode ser vazio");
         tfIDCliente.requestFocus();
         tfIDCliente.selectAll();
      } else {
         chavePrimaria = tfIDCliente.getText();//para uso no adicionar
         entidade = controle.buscar(String.valueOf(tfIDCliente.getText()));
         if (entidade == null) {//nao encontrou
            btAdicionar.setVisible(true);
            btAlterar.setVisible(false);
            btExcluir.setVisible(false);
            tfNumeroApartamento.setText("");
dtDiaEntrada.setText("");
dtDiaSaida.setText("");
            texto.setText("Não encontrou na lista - pode Adicionar\n\n\n");//limpa o campo texto

         } else {//encontrou
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            tfNumeroApartamento.setText(Integer.toString(entidade.getNumeroApartamento()));
            dtDiaEntrada.setText(formato.format(entidade.getDiaEntrada()));
            dtDiaSaida.setText(formato.format(entidade.getDiaSaida()));

            btAlterar.setVisible(true);
            btExcluir.setVisible(true);
            texto.setText("Encontrou na lista - pode Alterar ou Excluir\n\n\n");//limpa o campo texto

            tfNumeroApartamento.setEditable(false);
            dtDiaEntrada.setEnabled(false);
            dtDiaSaida.setEnabled(false);
         }
      }
   }
});
btAdicionar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      acao = "adicionar";
      tfIDCliente.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
      tfIDCliente.setEditable(false);
      tfNumeroApartamento.requestFocus();
      btSalvar.setVisible(true);
      btCancelar.setVisible(true);
      btBuscar.setVisible(false);
      btListar.setVisible(false);
      btAlterar.setVisible(false);
      btExcluir.setVisible(false);

      btAdicionar.setVisible(false);
      texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
      tfNumeroApartamento.setEditable(true);
      dtDiaEntrada.setEnabled(true);
      dtDiaSaida.setEnabled(true);
   }
});

btAlterar.addActionListener(new ActionListener() {   @Override
   public void actionPerformed(ActionEvent e) {
      acao = "alterar";
      tfIDCliente.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
      tfIDCliente.setEditable(false);
      tfNumeroApartamento.requestFocus();
      btSalvar.setVisible(true);
      btCancelar.setVisible(true);
      btBuscar.setVisible(false);
      btListar.setVisible(false);
      btAlterar.setVisible(false);
      btExcluir.setVisible(false);
      texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
      tfNumeroApartamento.setEditable(true);
      dtDiaEntrada.setEnabled(true);
      dtDiaSaida.setEnabled(true);
   }
});

btCancelar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      btSalvar.setVisible(false);
      btCancelar.setVisible(false);
      btBuscar.setVisible(true);
      btListar.setVisible(true);
      tfIDCliente.setEditable(true);

      tfNumeroApartamento.setText("");
      dtDiaEntrada.setText("");
      dtDiaSaida.setText("");

      tfIDCliente.requestFocus();
      tfIDCliente.selectAll();
      texto.setText("Cancelou\n\n\n\n\n");//limpa o campo texto

      tfNumeroApartamento.setEditable(false);
      dtDiaEntrada.setEditable(false);
      dtDiaSaida.setEditable(false);
   }
});

btSalvar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      if (acao.equals("alterar")) {
         Reserva1 entidadeAntigo = entidade;
         SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
          SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");

         entidade.setNumeroApartamento(Integer.valueOf(tfNumeroApartamento.getText()));
          try {
            entidade.setDiaEntrada(Date.valueOf(sdfEua.format(formato.parse(dtDiaEntrada.getText()))));
          } catch (ParseException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
          }          try {
            entidade.setDiaSaida(Date.valueOf(sdfEua.format(formato.parse(dtDiaSaida.getText()))));
          } catch (ParseException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
          }
         controle.alterar(entidade, entidadeAntigo);
          texto.setText("Registro alterado\n\n\n\n\n");//limpa o campo texto
      } else {//adicionar
         entidade = new Reserva1();
         SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
          SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");

         entidade.setIDCliente(Integer.valueOf(tfIDCliente.getText()));
         entidade.setNumeroApartamento(Integer.valueOf(tfNumeroApartamento.getText()));
         try {
            entidade.setDiaEntrada(Date.valueOf(sdfEua.format(formato.parse(dtDiaEntrada.getText()))));
         } catch (ParseException ex){
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
         }
         try {
            entidade.setDiaSaida(Date.valueOf(sdfEua.format(formato.parse(dtDiaSaida.getText()))));
         } catch (ParseException ex){
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
         }

         controle.adicionar(entidade);
         texto.setText("Foi adicionado um novo registro\n\n\n\n\n");//limpa o campo texto
      }
      btSalvar.setVisible(false);
      btCancelar.setVisible(false);
      btBuscar.setVisible(true);
      btListar.setVisible(true);
      tfIDCliente.setEditable(true);

      tfNumeroApartamento.setText("");
      dtDiaEntrada.setText("");
      dtDiaSaida.setText("");

      tfIDCliente.requestFocus();
      tfIDCliente.selectAll();

      tfNumeroApartamento.setEditable(false);
      dtDiaEntrada.setEditable(false);
      dtDiaSaida.setEditable(false);
   }
});

btExcluir.addActionListener(new ActionListener() {
   @Override   public void actionPerformed(ActionEvent e) {
      tfIDCliente.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
      if (JOptionPane.YES_OPTION
         == JOptionPane.showConfirmDialog(null,
            "Confirma a exclusão do registro <NumeroApartamento = " + entidade.getNumeroApartamento() + ">?", "Confirm",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {
         controle.excluir(entidade);
      }
      btBuscar.setVisible(true);
      btListar.setVisible(true);
      tfIDCliente.setEditable(true);

      tfNumeroApartamento.setText("");
      dtDiaEntrada.setText("");
      dtDiaSaida.setText("");

      tfIDCliente.requestFocus();
      tfIDCliente.selectAll();
      btExcluir.setVisible(false);
      btAlterar.setVisible(false);
      texto.setText("Excluiu o registro de " + entidade.getIDCliente() + " - " + entidade.getNumeroApartamento() + "\n\n\n\n\n");//limpa o campo texto
   }
});
btListar.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
      List<Reserva1> lt = controle.listar();


      String[] colunas = {"IDCliente", "NumeroApartamento", "DiaEntrada", "DiaSaida"};
      Object[][] dados = new Object[lt.size()][colunas.length];
      String aux[];
      for (int i = 0; i < lt.size(); i++) {
         aux = lt.get(i).toString().split(";");
         for (int j = 0; j < colunas.length; j++) {
            dados[i][j] = aux[j];
         }
      }
      cardLayout.show(painelSul, "Listagem");
      scrollTabela.setPreferredSize(tabela.getPreferredSize());
      painel2.add(scrollTabela);
      scrollTabela.setViewportView(tabela);
      model.setDataVector(dados, colunas);
      btAlterar.setVisible(false);
      btExcluir.setVisible(false);
      btAdicionar.setVisible(false);
   }
});
addWindowListener(new WindowAdapter() {
   @Override
   public void windowClosing(WindowEvent e) {
      //antes de sair, salvar a lista em disco
      btGravar.doClick();
      // Sai da classe
      dispose();
   }
});

setVisible(true);

//depois que a tela ficou visível, clic o botão automaticamente.
btCarregarDados.doClick();//execute o listener do btCarregarDados

}

}
