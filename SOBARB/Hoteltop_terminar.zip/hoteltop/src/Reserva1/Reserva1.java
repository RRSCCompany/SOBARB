package Reserva1;
 
import java.util.Date; 
public class Reserva1 { 

private int IDCliente;
private int NumeroApartamento;
private Date DiaEntrada;
private Date DiaSaida;

 public Reserva1() {
} 

public Reserva1(int IDCliente,int NumeroApartamento,Date DiaEntrada,Date DiaSaida) { 

this.IDCliente = IDCliente;
this.NumeroApartamento = NumeroApartamento;
this.DiaEntrada = DiaEntrada;
this.DiaSaida = DiaSaida;

}

public int getIDCliente() { 
return IDCliente; 
} 

public void setIDCliente(int IDCliente) { 
this.IDCliente = IDCliente; 
} 

public int getNumeroApartamento() { 
return NumeroApartamento; 
} 

public void setNumeroApartamento(int NumeroApartamento) { 
this.NumeroApartamento = NumeroApartamento; 
} 

public Date getDiaEntrada() { 
return DiaEntrada; 
} 

public void setDiaEntrada(Date DiaEntrada) { 
this.DiaEntrada = DiaEntrada; 
} 

public Date getDiaSaida() { 
return DiaSaida; 
} 

public void setDiaSaida(Date DiaSaida) { 
this.DiaSaida = DiaSaida; 
} 


@Override
public String toString() { 
    return IDCliente + ";" + NumeroApartamento + ";" + DiaEntrada + ";" + DiaSaida;
}

}
