
////////////CONTROLE////////////

package Cliente; 
import java.util.ArrayList;
import java.util.List;

public class Controle {

private List<Cliente> lista = new ArrayList<>();

public Controle() { 

} 


public void limparLista(){
   lista.clear(); 
}

public void adicionar(Cliente entidade) {
   lista.add(entidade);
}

public List<Cliente> listar() {
   return lista;
}


public Cliente buscar(String ID) {
   for (int i = 0; i < lista.size(); i++) {
      if (String.valueOf(lista.get(i).getID()).equals(ID)) {
         return lista.get(i);
      }
   }
   return null;
}

public void alterar(Cliente entidade,Cliente entidadeAntigo) {
   lista.set(lista.indexOf(entidadeAntigo), entidade);
}

public void excluir(Cliente entidade) {
   lista.remove(entidade);
}

}
