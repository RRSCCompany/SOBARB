package Apartamento;
 
public class Main { 
   public static void main(String[] args) {
     GIU gui = new GIU();
   }
}
