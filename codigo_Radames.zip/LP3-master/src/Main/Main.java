package Main;

import GUIs.GUIProduto;

/**
 *
 * @author radames
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new GUIProduto();
    }
    
}
