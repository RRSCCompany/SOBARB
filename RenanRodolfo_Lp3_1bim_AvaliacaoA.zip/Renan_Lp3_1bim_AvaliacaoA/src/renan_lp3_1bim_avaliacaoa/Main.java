package renan_lp3_1bim_avaliacaoa;
 
import GUIs.GUI;

public class Main { 
   public static void main(String[] args) {
     GUI gui = new GUI();
   }
}
