/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menu;
import GUIs.GUI;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import tools.Centraliza;
import tools.ManipulaImagem;

class MenuPrincipal extends JFrame{
    
    private JFrame cp = new JFrame();
    JPanel pnNorte = new JPanel();
    private JToolBar toolbar = new JToolBar();
 
    private JButton Apartamento;  
    private JLabel img;
    private JPanel p;
    private JPanel pn;
    private JButton Consumo;
    private ManipulaImagem manipulaimagem = new ManipulaImagem();


    public MenuPrincipal(Dimension dimensao) {
        cp.getContentPane();
        cp.setDefaultCloseOperation(DISPOSE_ON_CLOSE);;
        cp.setTitle("Menu Principal");
        cp.setSize(700, 700);
        cp.setLayout(new BorderLayout());
        setLocationRelativeTo(null);//centro do monitor   
        Centraliza centraliza = new Centraliza();
        centraliza.centralizaComponente(cp);
        cp.add(pnNorte, BorderLayout.NORTH);
        
        Apartamento = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/apartamentosfinal.png", 80,80), "Apartamentos");
        toolbar.add(Apartamento);
        toolbar.setBackground(Color.WHITE); 
        img = new JLabel(manipulaimagem.criaIcon("../imagenscrud/logomenufinal.png", 650, 580));
        pn = new JPanel();
        pn.setLayout(new GridLayout(1,1));
        pn.add(img);
        pn.setBackground(Color.BLACK);
        
        
        cp.add(toolbar, BorderLayout.NORTH);
        
        cp.add(pn, BorderLayout.CENTER);
//        pn = new JPanel();
//        pn.setLayout(new GridLayout(1,1));
//        pn.add(img);
//        pn.setBackground(Color.WHITE);
//        p = new JPanel();
//        p.setLayout(new GridLayout(1,1));
//        p.setBackground(Color.WHITE);     
//        toolbar.add(Apartamento);    
//        cp.add(toolbar, BorderLayout.NORTH);       
//        cp.add(pn, BorderLayout.CENTER);

        Apartamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUI gui = new GUI(cp);
            }
        });
                addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        cp.setVisible(true);
    }

    
}   
        