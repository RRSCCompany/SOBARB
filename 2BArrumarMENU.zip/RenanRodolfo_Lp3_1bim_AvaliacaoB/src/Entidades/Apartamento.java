/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Hotel
 */
@Entity
@Table(name = "apartamento")
@NamedQueries({
    @NamedQuery(name = "Apartamento.findAll", query = "SELECT a FROM Apartamento a")})
public class Apartamento implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "N_apartamento")
    private Integer napartamento;
    @Column(name = "Ar_Condicionado")
    private Boolean arCondicionado;
    @Column(name = "Hospede")
    private String hospede;
    @Column(name = "Qtde_Hospodes")
    private Integer qtdeHospodes;

    public Apartamento() {
    }

    public Apartamento(Integer napartamento) {
        this.napartamento = napartamento;
    }

    public Integer getNapartamento() {
        return napartamento;
    }

    public void setNapartamento(Integer napartamento) {
        this.napartamento = napartamento;
    }

    public Boolean getArCondicionado() {
        return arCondicionado;
    }

    public void setArCondicionado(Boolean arCondicionado) {
        this.arCondicionado = arCondicionado;
    }

    public String getHospede() {
        return hospede;
    }

    public void setHospede(String hospede) {
        this.hospede = hospede;
    }

    public Integer getQtdeHospodes() {
        return qtdeHospodes;
    }

    public void setQtdeHospodes(Integer qtdeHospodes) {
        this.qtdeHospodes = qtdeHospodes;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (napartamento != null ? napartamento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Apartamento)) {
            return false;
        }
        Apartamento other = (Apartamento) object;
        if ((this.napartamento == null && other.napartamento != null) || (this.napartamento != null && !this.napartamento.equals(other.napartamento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return napartamento + ";" + arCondicionado + ";" + hospede + ";" + qtdeHospodes;
    }
    
}
